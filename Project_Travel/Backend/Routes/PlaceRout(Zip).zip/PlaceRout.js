const express = require("express");
const router = express.Router();
const Place = require('../Schema/Place')
// GET all places
router.get('/allplaces', async (req, res) => {
  try {
    const places = await Place.find({});
    console.log("Fetched places:", places);

    res.status(200).json(places); // Return the fetched places
  } catch (error) {
    console.error("Error fetching places:", error);
    res.status(500).send("Server error...");
  }
});

///get by Id
router.get('/placedetails/:PlaceId', async (req, res) => {
  try {
    const places = await Place.findById({_id:req.params.PlaceId});
    console.log("Fetched places:", places);

    res.status(200).json(places); // Return the fetched places
  } catch (error) {
    console.error("Error fetching places:", error);
    res.status(500).send("Server error...");
  }
});

///Add Data
router.post('/add',async (req, res) => {
  try {
    
    // const place = new Place(req.body)
    // await place.save()
    
    const place = new Place({
      ...req.body,
      PackagePrice: Number(req.body.PackagePrice),
      Days: Number(req.body.Days)
    }).save()
    console.log("Fetched places:",place);
  
    res.status(200).json("added"); // Return the fetched places
  } catch (error) {
    console.error("Error fetching places:", error);
    res.status(500).send("Server error...");
  }
})

//Delete Data
router.delete('/:placeId',async(req,res)=>{
  try{
    const places = await Place.findById({_id:req.params.PlaceId});
    console.log("Fetched places:", places);
    const ans= await places.deleteOne(req.params.PlaceId)

  }catch(error){
    console.error("Error fetching places:", error);
    res.status(500).send("Server error...");
  }
})


module.exports = router;
